import 'dart:math';

import 'package:flutter/material.dart';

import '../game.dart';
import '../store.dart';
import 'game_screen.dart';

/// Paso 2: nombres de los jugadores y sorteo de quién reparte primero.
class NamesScreen extends StatefulWidget {
  const NamesScreen({
    super.key,
    required this.players,
    required this.deckSize,
    required this.maxCards,
  });

  final int players;
  final int deckSize;
  final int maxCards;

  @override
  State<NamesScreen> createState() => _NamesScreenState();
}

class _NamesScreenState extends State<NamesScreen> {
  late final List<TextEditingController> _ctrls = List.generate(
    widget.players,
    (_) => TextEditingController(),
  );

  int? _dealer;
  int? _highlight;
  bool _drawing = false;

  @override
  void dispose() {
    for (final c in _ctrls) {
      c.dispose();
    }
    super.dispose();
  }

  String _name(int i) {
    final s = _ctrls[i].text.trim();
    return s.isEmpty ? 'Jugador ${i + 1}' : s;
  }

  Future<void> _draw() async {
    if (_drawing) return;
    FocusScope.of(context).unfocus();

    final n = widget.players;
    final winner = Random().nextInt(n);
    const steps = 16;

    setState(() {
      _drawing = true;
      _dealer = null;
    });

    // La luz va saltando de jugador en jugador, cada vez más despacio,
    // y termina justo en el elegido.
    for (var i = 0; i < steps; i++) {
      if (!mounted) return;
      setState(() => _highlight = (winner - (steps - 1 - i)) % n);
      await Future<void>.delayed(Duration(milliseconds: 70 + i * 14));
    }

    if (!mounted) return;
    setState(() {
      _drawing = false;
      _dealer = winner;
      _highlight = null;
    });
  }

  void _start() {
    final dealer = _dealer;
    if (dealer == null) return;
    final names = [for (var i = 0; i < widget.players; i++) _name(i)];
    store.start(
      Game(
        players: names,
        deckSize: widget.deckSize,
        maxCards: widget.maxCards,
        firstDealer: dealer,
      ),
    );
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const GameScreen()),
      (route) => route.isFirst,
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final cs = t.colorScheme;
    final n = widget.players;
    final dealer = _dealer;

    return Scaffold(
      appBar: AppBar(title: const Text('Jugadores')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Escribe los nombres en el orden en que estáis sentados. '
                'El reparto irá pasando al siguiente de la lista.',
                style: t.textTheme.bodyMedium
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView.separated(
                  itemCount: n,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, i) {
                    final isDealer = !_drawing && dealer == i;
                    final active = _highlight == i || isDealer;
                    return TextField(
                      controller: _ctrls[i],
                      enabled: !_drawing,
                      textCapitalization: TextCapitalization.words,
                      textInputAction: i == n - 1
                          ? TextInputAction.done
                          : TextInputAction.next,
                      onChanged: (_) {
                        if (_dealer != null) setState(() {});
                      },
                      decoration: InputDecoration(
                        labelText: 'Jugador ${i + 1}',
                        filled: active,
                        fillColor: active ? cs.primaryContainer : null,
                        suffixIcon: isDealer
                            ? Icon(Icons.style, color: cs.primary)
                            : null,
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              if (dealer != null && !_drawing)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(
                    'Reparte primero ${_name(dealer)}',
                    textAlign: TextAlign.center,
                    style: t.textTheme.titleMedium,
                  ),
                ),
              OutlinedButton.icon(
                onPressed: _drawing ? null : _draw,
                icon: const Icon(Icons.shuffle),
                label: Text(
                  dealer == null ? 'Sortear quién reparte' : 'Sortear de nuevo',
                ),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: (dealer == null || _drawing) ? null : _start,
                child: const Text('Empezar partida'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
