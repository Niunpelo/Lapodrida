// Lógica pura del juego: rondas, apuestas y puntuación.
// No depende de Flutter, así que es fácil de probar.

enum Phase { bidding, results }

/// Barajas admitidas: número de cartas -> nombre.
const Map<int, String> decks = {
  48: 'Española · 48',
  52: 'Francesa · 52',
};

/// Máximo de cartas por jugador: se reparte toda la baraja siempre que se
/// pueda (si sobran cartas porque no sale exacto, se quedan en el mazo).
int maxCardsFor(int players, int deckSize) {
  final m = deckSize ~/ players;
  return m < 1 ? 1 : m;
}

/// Rondas de subida (1..máx) + rondas de bajada (máx-1..1).
int totalRoundsFor(int maxCards) => 2 * maxCards - 1;

/// Puntos de una ronda para un jugador.
/// - Acierta: 10 + 3 por cada baza pedida.
/// - Falla: -3 por cada baza de diferencia (de menos o de más).
/// Pedir 0 y hacer 0 también es acertar: 10 puntos.
int roundPoints(int bid, int won) {
  if (bid == won) return 10 + 3 * bid;
  return -3 * (bid - won).abs();
}

class RoundRecord {
  RoundRecord(this.bids, this.won);

  final List<int> bids;
  final List<int> won;

  Map<String, dynamic> toJson() => {'bids': bids, 'won': won};

  factory RoundRecord.fromJson(Map<String, dynamic> j) => RoundRecord(
        (j['bids'] as List).cast<int>().toList(),
        (j['won'] as List).cast<int>().toList(),
      );
}

class Game {
  Game({
    required this.players,
    required this.deckSize,
    required this.maxCards,
    required this.firstDealer,
    List<RoundRecord>? rounds,
    List<int>? bids,
    List<int>? won,
    this.phase = Phase.bidding,
  })  : rounds = rounds ?? <RoundRecord>[],
        bids = bids ?? List<int>.filled(players.length, 0),
        won = won ?? List<int>.filled(players.length, 0);

  final List<String> players;
  final int deckSize;
  final int maxCards;
  final int firstDealer;

  /// Rondas ya anotadas.
  final List<RoundRecord> rounds;

  /// Datos de la ronda en curso.
  List<int> bids;
  List<int> won;
  Phase phase;

  int get n => players.length;
  int get totalRounds => totalRoundsFor(maxCards);
  int get roundIndex => rounds.length;
  bool get finished => rounds.length >= totalRounds;

  int cardsForRound(int i) => i < maxCards ? i + 1 : 2 * maxCards - 1 - i;

  /// Cartas que se reparten a cada jugador en la ronda actual.
  int get cards => cardsForRound(roundIndex);

  /// True si en esta ronda se reparte toda la baraja (no queda mazo para
  /// dar la vuelta al triunfo, así que se enseña la última carta repartida).
  bool get allCardsDealt => cards * n == deckSize;

  String get roundKind {
    final i = roundIndex;
    if (i == maxCards - 1) return 'Ronda máxima';
    return i < maxCards - 1 ? 'Subida' : 'Bajada';
  }

  /// Quién reparte en la ronda actual (va pasando al siguiente de la lista).
  int get dealer => (firstDealer + roundIndex) % n;

  /// Orden de apuestas: empieza el que está después del repartidor
  /// y el repartidor apuesta el último.
  List<int> get bidOrder => [for (var k = 1; k <= n; k++) (dealer + k) % n];

  List<int> get totals {
    final t = List<int>.filled(n, 0);
    for (final r in rounds) {
      for (var i = 0; i < n; i++) {
        t[i] += roundPoints(r.bids[i], r.won[i]);
      }
    }
    return t;
  }

  int get bidSum => bids.fold(0, (a, b) => a + b);
  int get wonSum => won.fold(0, (a, b) => a + b);

  /// Número que el repartidor no puede pedir (porque las apuestas sumarían
  /// exactamente las cartas de la ronda), o null si no hay restricción.
  int? get forbiddenForDealer {
    var sum = 0;
    for (var i = 0; i < n; i++) {
      if (i != dealer) sum += bids[i];
    }
    final f = cards - sum;
    return (f >= 0 && f <= cards) ? f : null;
  }

  bool get bidsValid => forbiddenForDealer != bids[dealer];
  bool get resultsValid => wonSum == cards;

  // --- Acciones -----------------------------------------------------------

  void confirmBids() {
    phase = Phase.results;
  }

  void backToBids() {
    phase = Phase.bidding;
  }

  void finishRound() {
    rounds.add(RoundRecord(List<int>.of(bids), List<int>.of(won)));
    bids = List<int>.filled(n, 0);
    won = List<int>.filled(n, 0);
    phase = Phase.bidding;
  }

  /// Deshace la última ronda anotada y la deja abierta para corregirla.
  void undoLastRound() {
    if (rounds.isEmpty) return;
    final r = rounds.removeLast();
    bids = List<int>.of(r.bids);
    won = List<int>.of(r.won);
    phase = Phase.results;
  }

  // --- Persistencia -------------------------------------------------------

  Map<String, dynamic> toJson() => {
        'players': players,
        'deckSize': deckSize,
        'maxCards': maxCards,
        'firstDealer': firstDealer,
        'rounds': rounds.map((r) => r.toJson()).toList(),
        'bids': bids,
        'won': won,
        'phase': phase.name,
      };

  factory Game.fromJson(Map<String, dynamic> j) => Game(
        players: (j['players'] as List).cast<String>().toList(),
        deckSize: j['deckSize'] as int,
        maxCards: j['maxCards'] as int,
        firstDealer: j['firstDealer'] as int,
        rounds: (j['rounds'] as List)
            .map((e) => RoundRecord.fromJson(e as Map<String, dynamic>))
            .toList(),
        bids: (j['bids'] as List).cast<int>().toList(),
        won: (j['won'] as List).cast<int>().toList(),
        phase: Phase.values.byName(j['phase'] as String),
      );
}
