# La Podrida

Aplicación de apoyo para jugar a La Podrida con cartas de verdad: lleva los
turnos, las apuestas y los puntos. Hecha con Flutter (Dart).

## Cómo funciona

1. Eliges cuántos jugáis (3–10) y la baraja (española de 48 o francesa de 52).
2. La app calcula las rondas: subida de 1 al máximo de cartas y bajada hasta 1.
   El máximo es `cartas de la baraja ÷ jugadores` (redondeado hacia abajo): se
   reparte toda la baraja siempre que se pueda, y en esa ronda la última carta
   se enseña. Se puede ajustar a mano.
3. Escribes los nombres (en el orden en que estáis sentados) y sorteas quién reparte primero.
4. Cada ronda: anotas lo que pide cada uno (empezando por el de después del
   repartidor; el repartidor va el último y no puede cerrar la suma) y, al
   acabar de jugar, las bazas que ha hecho cada uno.

### Puntuación

- Aciertas: **10 puntos + 3 por cada baza pedida** (pedir 0 y hacer 0 son 10 puntos).
- Fallas: **−3 por cada baza** que te falte o te sobre.

Está en `roundPoints()` de `lib/game.dart` por si quieres cambiarla.

## Compilar el APK con GitHub

1. Crea un repositorio en GitHub y sube **todo** el contenido de esta carpeta,
   incluida la carpeta oculta `.github`:

   ```bash
   git init
   git add .
   git commit -m "La Podrida"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/la-podrida.git
   git push -u origin main
   ```

2. Entra en la pestaña **Actions** del repositorio. El workflow
   **Compilar APK** se lanza solo con cada `push` (también puedes pulsar
   *Run workflow*). Tarda unos 5–8 minutos.
3. Cuando termine, abre la ejecución y al final, en **Artifacts**, descarga
   `la-podrida-apk` (es un zip con `la-podrida.apk` dentro).

### APK descargable desde Releases (opcional)

Si subes una etiqueta, el APK aparece directamente en la pestaña **Releases**,
más cómodo para bajarlo desde el móvil:

```bash
git tag v1.0.0
git push --tags
```

### Instalarlo en el móvil

Copia el APK al teléfono y ábrelo. Android pedirá permiso para instalar
aplicaciones de origen desconocido para la app desde la que lo abras.

## Probarlo en local (opcional)

Con Flutter instalado:

```bash
flutter create --platforms=android --project-name la_podrida --org es.lapodrida .
flutter pub get
flutter run
```

## Estructura

```
lib/
  main.dart                  tema y arranque
  game.dart                  rondas, apuestas y puntuación (sin Flutter)
  store.dart                 guarda la partida en el móvil
  widgets.dart               selector numérico y diálogo
  screens/
    home_screen.dart         inicio
    setup_screen.dart        jugadores, baraja y rondas
    names_screen.dart        nombres y sorteo
    game_screen.dart         apuestas, bazas y resultado final
    scoreboard_screen.dart   tabla de puntos
```

El APK se firma con la clave de depuración de Flutter, así que se instala sin
problema, pero no sirve para subirlo a Google Play.
