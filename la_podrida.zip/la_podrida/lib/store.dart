import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'game.dart';

/// Guarda la partida en curso y la persiste en el móvil, para que no se
/// pierda si se cierra la app o se apaga la pantalla.
class GameStore extends ChangeNotifier {
  static const _key = 'podrida_game_v1';

  Game? game;
  SharedPreferences? _prefs;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs!.getString(_key);
    if (raw == null) return;
    try {
      game = Game.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      game = null;
    }
  }

  void start(Game g) {
    game = g;
    _save();
    notifyListeners();
  }

  /// Aplica un cambio a la partida actual, la guarda y avisa a la interfaz.
  void update(void Function(Game x) change) {
    final g = game;
    if (g == null) return;
    change(g);
    _save();
    notifyListeners();
  }

  void clear() {
    game = null;
    _prefs?.remove(_key);
    notifyListeners();
  }

  void _save() {
    final g = game;
    if (g == null) return;
    _prefs?.setString(_key, jsonEncode(g.toJson()));
  }
}

final GameStore store = GameStore();
