import 'package:flutter/material.dart';

import '../game.dart';
import '../widgets.dart';
import 'names_screen.dart';

/// Paso 1: cuántos jugadores y qué baraja. Calcula las rondas.
class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  int _players = 4;
  int _deck = 48;
  int? _maxOverride;

  int get _autoMax => maxCardsFor(_players, _deck);

  int get _maxCards {
    final m = _maxOverride ?? _autoMax;
    if (m > _autoMax) return _autoMax;
    if (m < 1) return 1;
    return m;
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final cs = t.colorScheme;
    final maxC = _maxCards;
    final total = totalRoundsFor(maxC);

    return Scaffold(
      appBar: AppBar(title: const Text('Nueva partida')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: ListView(
                  children: [
                    const _Label('¿Cuántos jugáis?'),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '$_players jugadores',
                            style: t.textTheme.headlineSmall,
                          ),
                        ),
                        NumberStepper(
                          value: _players,
                          min: 3,
                          max: 10,
                          onChanged: (v) => setState(() {
                            _players = v;
                            _maxOverride = null;
                          }),
                        ),
                      ],
                    ),
                    const SizedBox(height: 32),
                    const _Label('¿Con qué baraja?'),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final e in decks.entries)
                          ChoiceChip(
                            label: Text(e.value),
                            selected: _deck == e.key,
                            onSelected: (_) => setState(() {
                              _deck = e.key;
                              _maxOverride = null;
                            }),
                          ),
                      ],
                    ),
                    const SizedBox(height: 32),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: cs.surfaceContainerLow,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '$total rondas',
                            style: t.textTheme.headlineMedium
                                ?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '$maxC de subida y ${maxC - 1} de bajada\n'
                            'De 1 a $maxC cartas por jugador',
                            style: t.textTheme.bodyMedium
                                ?.copyWith(color: cs.onSurfaceVariant),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              const Expanded(child: Text('Máximo de cartas')),
                              NumberStepper(
                                value: maxC,
                                min: 1,
                                max: _autoMax,
                                onChanged: (v) =>
                                    setState(() => _maxOverride = v),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => NamesScreen(
                        players: _players,
                        deckSize: _deck,
                        maxCards: maxC,
                      ),
                    ),
                  );
                },
                child: const Text('Siguiente'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        text,
        style: t.textTheme.titleMedium
            ?.copyWith(color: t.colorScheme.onSurfaceVariant),
      ),
    );
  }
}
