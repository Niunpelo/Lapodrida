import 'package:flutter/material.dart';

import '../game.dart';
import '../store.dart';
import '../widgets.dart';
import 'scoreboard_screen.dart';
import 'setup_screen.dart';

/// Pantalla de partida: muestra la ronda en curso o el resultado final.
class GameScreen extends StatelessWidget {
  const GameScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final g = store.game;
        if (g == null) return const Scaffold();
        return g.finished ? FinalView(game: g) : RoundView(game: g);
      },
    );
  }
}

void _openScoreboard(BuildContext context) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => const ScoreboardScreen()),
  );
}

// ---------------------------------------------------------------------------
// Ronda en curso: apuestas -> bazas ganadas
// ---------------------------------------------------------------------------

class RoundView extends StatelessWidget {
  const RoundView({super.key, required this.game});

  final Game game;

  @override
  Widget build(BuildContext context) {
    final g = game;
    final t = Theme.of(context);
    final cs = t.colorScheme;
    final bidding = g.phase == Phase.bidding;
    final cards = g.cards;
    final cardsLabel = cards == 1 ? 'carta' : 'cartas';
    final dealerName = g.players[g.dealer];
    final order = g.bidOrder;
    final totals = g.totals;
    final isLastRound = g.roundIndex == g.totalRounds - 1;

    final rows = <Widget>[];
    for (var k = 0; k < order.length; k++) {
      final p = order[k];
      final isDealer = p == g.dealer;

      InlineSpan subtitle;
      if (bidding) {
        final tag = isDealer ? ' · reparte' : '';
        subtitle = TextSpan(text: '${totals[p]} pts$tag');
      } else {
        final pts = roundPoints(g.bids[p], g.won[p]);
        subtitle = TextSpan(
          text: 'Pidió ${g.bids[p]} · ',
          children: [
            TextSpan(
              text: '${fmtPts(pts)} pts',
              style: TextStyle(
                color: ptsColor(context, pts),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        );
      }

      rows.add(
        _PlayerRow(
          position: k + 1,
          name: g.players[p],
          isDealer: isDealer,
          subtitle: subtitle,
          value: bidding ? g.bids[p] : g.won[p],
          max: cards,
          onChanged: (v) => store.update((x) {
            if (bidding) {
              x.bids[p] = v;
            } else {
              x.won[p] = v;
            }
          }),
        ),
      );
    }

    // Información y botones del pie.
    final List<Widget> footer;
    if (bidding) {
      final f = g.forbiddenForDealer;
      final bad = !g.bidsValid;
      footer = [
        Text(
          'Apuestas: ${g.bidSum} de $cards',
          style: t.textTheme.bodyMedium?.copyWith(color: cs.onSurfaceVariant),
        ),
        if (f != null)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(
              '$dealerName reparte y no puede pedir $f',
              style: t.textTheme.bodyMedium?.copyWith(
                color: bad ? cs.error : cs.onSurfaceVariant,
                fontWeight: bad ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ),
        const SizedBox(height: 12),
        FilledButton(
          onPressed:
              bad ? null : () => store.update((x) => x.confirmBids()),
          child: const Text('Empezar ronda'),
        ),
      ];
    } else {
      final ok = g.resultsValid;
      footer = [
        Text(
          ok
              ? 'Bazas: ${g.wonSum} de $cards'
              : 'Bazas: ${g.wonSum} de $cards · tienen que sumar $cards',
          style: t.textTheme.bodyMedium?.copyWith(
            color: ok ? cs.onSurfaceVariant : cs.error,
          ),
        ),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: ok ? () => store.update((x) => x.finishRound()) : null,
          child: Text(isLastRound ? 'Anotar y ver resultado' : 'Anotar ronda'),
        ),
        const SizedBox(height: 4),
        TextButton(
          onPressed: () => store.update((x) => x.backToBids()),
          child: const Text('Corregir apuestas'),
        ),
      ];
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Ronda ${g.roundIndex + 1} de ${g.totalRounds}'),
        actions: [
          IconButton(
            tooltip: 'Puntuaciones',
            icon: const Icon(Icons.leaderboard_outlined),
            onPressed: () => _openScoreboard(context),
          ),
          _GameMenu(game: g),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '$cards $cardsLabel',
                          style: t.textTheme.displaySmall
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${g.roundKind} · reparte $dealerName',
                          style: t.textTheme.bodyLarge
                              ?.copyWith(color: cs.onSurfaceVariant),
                        ),
                        if (g.allCardsDealt)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              'Se reparten todas las cartas: la última se enseña.',
                              style: t.textTheme.bodyMedium
                                  ?.copyWith(color: cs.primary),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  bidding
                      ? 'Apuestas, por orden · empieza ${g.players[order.first]}'
                      : 'Bazas ganadas · apunta cuántas ha hecho cada uno',
                  style: t.textTheme.titleSmall
                      ?.copyWith(color: cs.onSurfaceVariant),
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
                children: rows,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: footer,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlayerRow extends StatelessWidget {
  const _PlayerRow({
    required this.position,
    required this.name,
    required this.isDealer,
    required this.subtitle,
    required this.value,
    required this.max,
    required this.onChanged,
  });

  final int position;
  final String name;
  final bool isDealer;
  final InlineSpan subtitle;
  final int value;
  final int max;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final cs = t.colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          CircleAvatar(
            radius: 14,
            backgroundColor: isDealer ? cs.primary : cs.surfaceContainerHighest,
            foregroundColor: isDealer ? cs.onPrimary : cs.onSurfaceVariant,
            child: Text('$position', style: const TextStyle(fontSize: 12)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: t.textTheme.titleMedium,
                ),
                Text.rich(
                  subtitle,
                  style: t.textTheme.bodySmall
                      ?.copyWith(color: cs.onSurfaceVariant),
                ),
              ],
            ),
          ),
          NumberStepper(
            value: value,
            min: 0,
            max: max,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Menú de la partida
// ---------------------------------------------------------------------------

class _GameMenu extends StatelessWidget {
  const _GameMenu({required this.game});

  final Game game;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      onSelected: (value) async {
        if (value == 'undo') {
          store.update((x) => x.undoLastRound());
        } else if (value == 'end') {
          final ok = await confirmDialog(
            context,
            title: 'Terminar partida',
            message: 'Se borrará la partida en curso.',
            action: 'Terminar',
          );
          if (ok && context.mounted) {
            store.clear();
            Navigator.of(context).popUntil((r) => r.isFirst);
          }
        }
      },
      itemBuilder: (_) => [
        PopupMenuItem<String>(
          value: 'undo',
          enabled: game.rounds.isNotEmpty,
          child: const Text('Deshacer última ronda'),
        ),
        const PopupMenuItem<String>(
          value: 'end',
          child: Text('Terminar partida'),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Resultado final
// ---------------------------------------------------------------------------

class FinalView extends StatelessWidget {
  const FinalView({super.key, required this.game});

  final Game game;

  @override
  Widget build(BuildContext context) {
    final g = game;
    final t = Theme.of(context);
    final cs = t.colorScheme;
    final totals = g.totals;

    final order = List<int>.generate(g.n, (i) => i)
      ..sort((a, b) => totals[b].compareTo(totals[a]));
    final best = totals.reduce((a, b) => a > b ? a : b);
    final winners = [
      for (var i = 0; i < g.n; i++)
        if (totals[i] == best) g.players[i],
    ];
    final joined = winners.join(' y ');
    final title = winners.length == 1 ? 'Gana $joined' : 'Empate: $joined';

    int rankOf(int idx) => 1 + totals.where((x) => x > totals[idx]).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Fin de la partida'),
        actions: [_GameMenu(game: g)],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                title,
                style: t.textTheme.headlineMedium
                    ?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView(
                  children: [
                    for (final p in order)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 36,
                              child: Text(
                                '${rankOf(p)}º',
                                style: t.textTheme.titleMedium
                                    ?.copyWith(color: cs.onSurfaceVariant),
                              ),
                            ),
                            Expanded(
                              child: Text(
                                g.players[p],
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: t.textTheme.titleMedium?.copyWith(
                                  fontWeight: rankOf(p) == 1
                                      ? FontWeight.w700
                                      : FontWeight.w400,
                                ),
                              ),
                            ),
                            Text(
                              '${totals[p]} pts',
                              style: t.textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: ptsColor(context, totals[p]),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: () => _openScoreboard(context),
                child: const Text('Ver todas las puntuaciones'),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () {
                  store.clear();
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute<void>(
                      builder: (_) => const SetupScreen(),
                    ),
                    (route) => route.isFirst,
                  );
                },
                child: const Text('Nueva partida'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
