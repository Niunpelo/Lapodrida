import 'package:flutter/material.dart';

import '../game.dart';
import '../store.dart';
import '../widgets.dart';

/// Tabla con los puntos de cada ronda y el total de cada jugador.
class ScoreboardScreen extends StatelessWidget {
  const ScoreboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Puntuaciones')),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: store,
          builder: (context, _) {
            final g = store.game;
            if (g == null) return const SizedBox.shrink();
            return _Table(game: g);
          },
        ),
      ),
    );
  }
}

class _Table extends StatelessWidget {
  const _Table({required this.game});

  final Game game;

  DataRow _roundRow(BuildContext context, int r) {
    final t = Theme.of(context);
    final small = t.textTheme.bodySmall
        ?.copyWith(color: t.colorScheme.onSurfaceVariant);
    final rec = game.rounds[r];
    final c = game.cardsForRound(r);
    final cardsLabel = c == 1 ? 'carta' : 'cartas';

    return DataRow(
      cells: [
        DataCell(
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Ronda ${r + 1}'),
              Text('$c $cardsLabel', style: small),
            ],
          ),
        ),
        for (var i = 0; i < game.n; i++)
          DataCell(
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  fmtPts(roundPoints(rec.bids[i], rec.won[i])),
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: ptsColor(
                      context,
                      roundPoints(rec.bids[i], rec.won[i]),
                    ),
                  ),
                ),
                Text(
                  'pidió ${rec.bids[i]} · hizo ${rec.won[i]}',
                  style: small,
                ),
              ],
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final g = game;
    final t = Theme.of(context);
    final cs = t.colorScheme;
    final totals = g.totals;

    final columns = <DataColumn>[
      const DataColumn(label: Text('')),
      for (final name in g.players)
        DataColumn(
          label: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 90),
            child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
        ),
    ];

    final rows = <DataRow>[
      DataRow(
        cells: [
          DataCell(
            Text(
              'Total',
              style: t.textTheme.titleSmall
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
          ),
          for (var i = 0; i < g.n; i++)
            DataCell(
              Text(
                '${totals[i]}',
                style: t.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: ptsColor(context, totals[i]),
                ),
              ),
            ),
        ],
      ),
      for (var r = 0; r < g.rounds.length; r++) _roundRow(context, r),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (g.rounds.isEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 8, 24, 8),
            child: Text(
              'Todavía no hay rondas anotadas.',
              style: t.textTheme.bodyMedium?.copyWith(color: cs.onSurfaceVariant),
            ),
          ),
        Expanded(
          child: SingleChildScrollView(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columnSpacing: 20,
                columns: columns,
                rows: rows,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
