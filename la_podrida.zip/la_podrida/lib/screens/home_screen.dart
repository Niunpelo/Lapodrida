import 'package:flutter/material.dart';

import '../store.dart';
import 'game_screen.dart';
import 'setup_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _newGame(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const SetupScreen()),
    );
  }

  void _continue(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const GameScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final cs = t.colorScheme;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: ListenableBuilder(
            listenable: store,
            builder: (context, _) {
              final g = store.game;
              final continueLabel = g == null
                  ? ''
                  : (g.finished
                      ? 'Ver resultado'
                      : 'Continuar · ronda ${g.roundIndex + 1} de ${g.totalRounds}');

              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Spacer(),
                  Icon(Icons.style_outlined, size: 56, color: cs.primary),
                  const SizedBox(height: 16),
                  Text(
                    'La Podrida',
                    style: t.textTheme.displaySmall
                        ?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Turnos y puntos para jugar con cartas de verdad.',
                    style: t.textTheme.bodyLarge
                        ?.copyWith(color: cs.onSurfaceVariant),
                  ),
                  const Spacer(),
                  if (g != null) ...[
                    FilledButton(
                      onPressed: () => _continue(context),
                      child: Text(continueLabel),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      onPressed: () => _newGame(context),
                      child: const Text('Nueva partida'),
                    ),
                  ] else
                    FilledButton(
                      onPressed: () => _newGame(context),
                      child: const Text('Nueva partida'),
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
